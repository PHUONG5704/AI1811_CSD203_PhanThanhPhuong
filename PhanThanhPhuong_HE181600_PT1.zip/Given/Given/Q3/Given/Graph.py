import math
from Stack import *
class Graph:
    def __init__(self,data):
        self.a = data
    def display(self):
        for i in range(len(self.a)):
            for j in range(len(self.a[i])):
                print(self.a[i][j], end =" ")
            print("")
        print("")
    def depthFirst(self,start):
        b = [True]*len(self.a)
        b[start] = False    
        self.depth(start,b)
        for i in range(len(b)):
            if b[i]:
                b[i] = False
                self.depth(i,b)
    def depth(self,start,b):
        t = self.deg(start)
        print(f"{chr(start+65)}", end = " ")    
        for i in range(len(b)):
            if self.a[start][i]!=0 and b[i]:
                b[i] = False
                self.depth(i,b)
    def deg(self, x):
        count =0
        for i in range(len(self.a)):
            count += self.a[x][i]
        return count
    #----------------------------
    def f1(self,start):
        self.depthFirst(start)
        print("")
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART 1========



        #---------------------------
        print("\nFINISH")
    
    #----------------------------    
    '''Algorithm for finding an Euler cycle from the vertex X using stack 
//Input: Connected graph G with all vertices having even degrees
//Output: Euler cycle
declare a stack S of characters
declare empty array E (which will contain Euler cycle)
push the vertex X to S
while(S is not empty)
 {r = top element of the stack S 
  if r is isolated then remove it from the stack and put it to E
   else
   select the first vertex Y (by alphabet order), which is adjacent
   to r, push  Y  to  S and remove the edge (r,Y) from the graph   
 }
 the last array E obtained is an Euler cycle of the graph'''
    #-------------------------------------
    def f2(self,start):
        #===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART 2 ========
         stack = Stack()
         euler_cycle = []

         stack.push(start)

         while not stack.isEmpty():
            r = stack.peek()

            isolated = True
            for i in range(len(self.a[r])):
                if self.a[r][i] != 0:
                    isolated = False
                    stack.push(i)
                    self.a[r][i] -= 1
                    self.a[i][r] -= 1
                    break

                if isolated:
                   euler_cycle.append(stack.pop())

                   output = " ".join([chr(vertex + 65) for vertex in euler_cycle[::-1]])



        #------------------------------
                print(f"OUTPUT\n{output}\nFINISH")
        

    # -----------------------------
    def f3(self,start,end):
        distances = [math.inf] * len(self.a)
        visited = [False] * len(self.a)
        distances[start] = 0

        for _ in range(len(self.a)):
            u = self.minDistance(distances, visited)
            visited[u] = True

            for v in range(len(self.a)):
                if self.a[u][v] and not visited[v] and distances[v] > distances[u] + self.a[u][v]:
                    distances[v] = distances[u] + self.a[u][v]

        path = [chr(end + 65)]
        vertex = end
        while vertex != start:
            for i in range(len(self.a)):
                if self.a[vertex][i] > 0 and distances[vertex] == distances[i] + self.a[vertex][i]:
                    path.append(chr(i + 65))
                    vertex = i
                    break

        output_path = " ".join(path[::-1])
        output_distance = " ".join([str(distance) for distance in distances])
        print(f"OUTPUT\n{output_path}\n{output_distance}\nFINISH")

    def minDistance(self,distances,visited):
        min_distance = math.inf
        min_index = -1
        for v in range(len(self.a)):
            if distances[v] < min_distance and not visited[v]:
                min_distance = distances[v]
                min_index = v
        return min_index
        pass
