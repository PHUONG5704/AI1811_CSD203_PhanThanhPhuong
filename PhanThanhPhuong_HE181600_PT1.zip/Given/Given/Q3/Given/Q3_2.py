class Q3_2:
    def f2(self, a, start): 
        #a is the adjacency matrix representing the given graph
        # start is a starting point
        
        def f2(self, a, start):
            def euler_cycle(v):
                cycle = []
                stack = [v]

            while stack:
                current_vertex = stack[-1]
                next_vertex = -1

                for i in range(len(a[current_vertex])):
                    if a[current_vertex][i] > 0:
                        next_vertex = i
                        break

                if next_vertex == -1:
                    cycle.append(stack.pop())
                else:
                    stack.append(next_vertex)
                    a[current_vertex][next_vertex] -= 1

            return cycle

        cycle = euler_cycle(start)
        output = " ".join([chr(vertex + 65) for vertex in cycle[::-1]]) + "\nFINISH"
        with open("f2.txt", "w") as file:
            file.write(output)
        pass
        