class Q3_1:
    def f1(self, a, start): 
        #a is the adjacency matrix representing the given graph
        # start is a starting point
        visited = [False] * len(a)
        degrees = [0] * len(a)
        vertex_labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']

        def depth2(v):
            visited[v] = True
            degrees[v] = sum(a[v])
            for i in range(len(a)):
                if a[v][i] and not visited[i]:
                    depth2(i)

        depth2(start)

        result = [(vertex_labels[i], degrees[i]) for i in range(len(degrees)) if visited[i]]
        
        output = ""
        for vertex, degree in result:
            output += f"{vertex}({degree}) "
        output += "\nFINISH"
        with open("f1.txt", "w") as file:
            file.write(output)
        pass
        