class Q3_3:
    def f3(self, a, start, end): 
        #a is the adjacency matrix representing the given graph
        # start is a starting point
        # end is a ending point
        def f3(self, a, start, end):
            import heapq

        distances = [float('inf')] * len(a)
        distances[start] = 0
        heap = [(0, start)]

        while heap:
            current_distance, current_vertex = heapq.heappop(heap)

            if current_distance > distances[current_vertex]:
                continue

            for next_vertex, weight in enumerate(a[current_vertex]):
                if weight > 0:
                    distance = current_distance + weight
                    if distance < distances[next_vertex]:
                        distances[next_vertex] = distance
                        heapq.heappush(heap, (distance, next_vertex))

        path = [chr(end + 65)]
        vertex = end
        while vertex != start:
            for i, weight in enumerate(a[vertex]):
                if weight > 0 and distances[vertex] == distances[i] + weight:
                    path.append(chr(i + 65))
                    vertex = i
                    break

        output_path = " ".join(path[::-1])
        output_distance = " ".join([str(distance) for distance in distances])
        output = f"{output_path}\n{output_distance}\nFINISH"
        with open("f3.txt", "w") as file:
            file.write(output)
        pass
        