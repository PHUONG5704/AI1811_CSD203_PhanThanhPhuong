def deleteBooks(book_list):
    if not book_list or not book_list.head:
        print("There is not any book in library!")
        return

    delete_bid = input("Enter id of book to delete: ")
    current = book_list.head
    previous = None

    while current:
        if current.bid == delete_bid:
            if previous:
                previous.next = current.next
                if current == book_list.tail:
                    book_list.tail = previous
            else:
                book_list.head = current.next
                if current == book_list.tail:
                    book_list.tail = None
            print(f"Book with id {delete_bid} deleted successfully!")
            return

        previous = current
        current = current.next

    print(f"Book with id {delete_bid} not found!")