class BorrowedBook:
    def __init__(self, bid, borrower):
        self.bid = bid
        self.borrower = borrower
        self.next = None

class BorrowedBookList:
    def __init__(self):
        self.head = None
        self.tail = None

    def borrow_Books(self, bid, borrower):
        new_borrowed_book = BorrowedBook(bid, borrower)
        if not self.head:
            self.head = new_borrowed_book
            self.tail = new_borrowed_book

        else:
            self.tail.next = new_borrowed_book
            self.tail = new_borrowed_book

def borrowBooks(book_list, borrowed_book_list):
    if not book_list or not book_list.head:
        print("There is not any book in library!")
        return

    borrow_bid = input("Enter id of book to borrow: ")
    borrower_name = input("Enter the name of borrower: ")

    current = book_list.head
    while current:
        if current.bid == borrow_bid and current.status == "0":
            current.status = "1"
            if borrowed_book_list is None:
                borrowed_book_list = BorrowedBookList()
            borrowed_book_list.borrow_Books(borrow_bid, borrower_name)
            print(f"Book with id {borrow_bid} borrowed successfully!")
            return
        current = current.next
    print(f"Book with id {borrow_bid} not available or not be borrowed!")