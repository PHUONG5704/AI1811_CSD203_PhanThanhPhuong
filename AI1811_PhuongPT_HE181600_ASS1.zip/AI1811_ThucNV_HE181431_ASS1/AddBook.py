class Book:
    def __init__(self, bid, title, author, status):
        self.bid = bid
        self.title = title
        self.author = author
        self.status = status
        self.next = None
class BookList:
    def __init__(self):
        self.head = None
        self.tail = None

    def add_Books(self, bid, title, author, status):
        new_book = Book(bid, title, author, status)
        if not self.head:
            self.head = new_book
            self.tail = new_book
        else:
            self.tail.next = new_book
            self.tail = new_book

def addBooks(book_list):
    bid = input("Enter id of book: ")
    title = input("Enter title of book: ")
    author = input("Enter author of booK: ")
    status = "0"

    if book_list is None:
        book_list = BookList()

    book_list.add_Books(bid, title, author, status)
    print("Add Book Successfully!")

