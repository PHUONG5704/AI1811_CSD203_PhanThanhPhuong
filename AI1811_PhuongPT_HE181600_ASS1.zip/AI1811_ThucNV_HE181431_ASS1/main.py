from AddBook import *
from ViewBooks import viewBooks
from DeleteBook import deleteBooks
from BorrowedBook import *
from ReturnBook import *

def Menu():
    print("Choose the number to manage Library System: ")
    print("1. Add Books")
    print("2. View Books")
    print("3. Delete Books")
    print("4. Borrow Books")
    print("5. Return Books")
    print("e. Exit")

class Main:
    book_list = BookList()
    borrowed_book_list = BorrowedBookList()

    while True:
        Menu()
        choice = input("Enter number 1 to 5 or e to exit: ")

        if choice == "1":
            addBooks(book_list)
        elif choice == "2":
            viewBooks(book_list)
        elif choice == "3":
            deleteBooks(book_list)
        elif choice == "4":
            borrowBooks(book_list, borrowed_book_list)
        elif choice == "5":
            returnBooks(book_list, borrowed_book_list)
        elif choice == "e":
            break
        else:
            print("Please enter valid choice!")