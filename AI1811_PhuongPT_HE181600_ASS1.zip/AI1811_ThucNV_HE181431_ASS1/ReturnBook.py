def returnBooks(book_list, borrowed_book_list):
    if not borrowed_book_list or not borrowed_book_list.head:
        print("There is no borrowed book to return!")
        return

    return_bid = input("Enter id of book to return: ")

    current = borrowed_book_list.head
    previous = None

    while current:
        if current.bid == return_bid:
            current_to_update = book_list.head
            while current_to_update:
                if current_to_update.bid == return_bid:
                    current_to_update.status = "0"
                    break
                current_to_update = current_to_update.next

            if previous:
                previous.next = current.next
                if current == borrowed_book_list.tail:
                    borrowed_book_list.tail = previous
            else:
                borrowed_book_list.head = current.next
                if current == borrowed_book_list.tail:
                    borrowed_book_list.tail = None
            print(f"Book with id {return_bid} returned successfully!")
            return
        previous = current
        current = current.next

    print(f"Book with id {return_bid} not found in borrowed books list!")