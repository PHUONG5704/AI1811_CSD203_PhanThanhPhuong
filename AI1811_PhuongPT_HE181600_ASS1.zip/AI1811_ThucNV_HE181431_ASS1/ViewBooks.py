def viewBooks(book_list):
    if not book_list or not book_list.head:
        print("There is not any book in library!")
        return

    current = book_list.head
    print("Bid  | Title       | Author       | Status ")
    print("-------------------------------------------")
    while current:
        print(f"{current.bid}  | {current.title}       | {current.author}        | {current.status}")
        current = current.next